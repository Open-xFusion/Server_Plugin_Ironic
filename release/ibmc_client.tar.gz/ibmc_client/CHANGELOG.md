## 0.2.3 (2020-05-20)
 * adjust delete raid configuration feature: 
    * remove restore controller action
    * do not update drive state when JBOD
 * add storage summary feature

## 0.2.2 (2020-05-14)
 * add typing lib for python<3.5

## 0.2.1 (2020-05-14)
 * Add OOBSupport check
 * remove __version__ dependency in setup.py

## 0.2.0 (2020-05-14)
 * Add RAID configuration support.

## 0.0.2 (2019-02-19)
 * Fix classifiers.

## 0.0.1 (2019-02-19)
 * Initial release.
